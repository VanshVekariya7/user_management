var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

List<User> users = new List<User>()
{
    new User { Id = 1, Name = "Meebs", Email = "meebs@mail.com" }
};

// GET all users
app.MapGet("/users", () => users);

// GET by ID
app.MapGet("/users/{id}", (int id) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    return user is not null ? Results.Ok(user) : Results.NotFound();
});

// POST
app.MapPost("/users", (User user) =>
{
    if (string.IsNullOrEmpty(user.Name) || string.IsNullOrEmpty(user.Email))
        return Results.BadRequest("Invalid data");

    user.Id = users.Count + 1;
    users.Add(user);
    return Results.Ok(user);
});

// PUT
app.MapPut("/users/{id}", (int id, User updatedUser) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    if (user is null) return Results.NotFound();

    user.Name = updatedUser.Name;
    user.Email = updatedUser.Email;

    return Results.Ok(user);
});

// DELETE
app.MapDelete("/users/{id}", (int id) =>
{
    var user = users.FirstOrDefault(u => u.Id == id);
    if (user is null) return Results.NotFound();

    users.Remove(user);
    return Results.Ok();
});

app.Run();

record User
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
}